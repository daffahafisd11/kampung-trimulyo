<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\LandingController;
use App\Http\Controllers\ProfileController;

// Controller RW
use App\Http\Controllers\Rw\RtController;
use App\Http\Controllers\Rw\KategoriPengaduanController;
use App\Http\Controllers\Rw\KategoriUmkmController;
use App\Http\Controllers\Rw\WargaController;
use App\Http\Controllers\Rw\PengaduanController as RwPengaduanController;
use App\Http\Controllers\Rw\UmkmController as RwUmkmController;
use App\Http\Controllers\Rw\InformasiController as RwInformasiController;
use App\Http\Controllers\Rw\KegiatanController as RwKegiatanController;
use App\Http\Controllers\Rw\KasController as RwKasController;
use App\Http\Controllers\Rw\BendaharaController as RwBendaharaController;
use App\Http\Controllers\Rw\AkunRtController;

// Controller RT
use App\Http\Controllers\Rt\PengaduanController as RtPengaduanController;
use App\Http\Controllers\Rt\UmkmController as RtUmkmController;
use App\Http\Controllers\Rt\InformasiController as RtInformasiController;
use App\Http\Controllers\Rt\KegiatanController as RtKegiatanController;
use App\Http\Controllers\Rt\KasController as RtKasController;
use App\Http\Controllers\Rt\WargaController as RtWargaController;

// Controller Bendahara
use App\Http\Controllers\Bendahara\KasController as BendaharaKasController;

// Controller Warga
use App\Http\Controllers\Warga\PengaduanController as WargaPengaduanController;
use App\Http\Controllers\Warga\UmkmController as WargaUmkmController;
use App\Http\Controllers\Warga\ProfileController as WargaProfileController;
use App\Http\Controllers\Warga\KasController as WargaKasController;


/*
|--------------------------------------------------------------------------
| LOGIN & LOGOUT
|--------------------------------------------------------------------------
*/

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

Route::post('/logout', [AuthController::class, 'logout'])
    ->middleware('auth')
    ->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/profile/change-password', [ProfileController::class, 'showChangePassword'])->name('profile.change-password');
    Route::post('/profile/change-password', [ProfileController::class, 'changePassword'])->name('profile.change-password.update');
});


Route::get('/', [LandingController::class, 'index'])->name('landing');


/*
|--------------------------------------------------------------------------
| RW (Super Admin)
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'role:rw'])->prefix('rw')->name('rw.')->group(function () {

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'rw'])->name('dashboard');

    // Master Data
    Route::resource('rt', RtController::class);
    Route::resource('kategori-pengaduan', KategoriPengaduanController::class);
    Route::resource('kategori-umkm', KategoriUmkmController::class);

    // Data Inti
    Route::resource('warga', WargaController::class);
    Route::resource('pengaduan', RwPengaduanController::class);
    Route::resource('umkm', RwUmkmController::class);

    // Informasi & Kegiatan
    Route::resource('informasi', RwInformasiController::class);
    Route::resource('kegiatan', RwKegiatanController::class);

    // ==================== KAS RT (RW bisa lihat semua) ====================
    Route::get('/kas', [RwKasController::class, 'index'])->name('kas.index');
    Route::get('/kas/{rt}', [RwKasController::class, 'show'])->name('kas.show');
    Route::delete('/kas/{kas}', [RwKasController::class, 'destroy'])->name('kas.destroy');

    // ==================== KELOLA BENDAHARA ====================
    Route::get('/bendahara', [RwBendaharaController::class, 'index'])->name('bendahara.index');
    Route::get('/bendahara/{rt}/edit', [RwBendaharaController::class, 'edit'])->name('bendahara.edit');
    Route::put('/bendahara/{rt}', [RwBendaharaController::class, 'update'])->name('bendahara.update');

    Route::get('/akun-rt', [AkunRtController::class, 'index'])->name('akun-rt.index');
    Route::get('/akun-rt/{user}/edit', [AkunRtController::class, 'edit'])->name('akun-rt.edit');
    Route::put('/akun-rt/{user}', [AkunRtController::class, 'update'])->name('akun-rt.update');
    Route::get('/akun-rt/{user}/reset-password', [AkunRtController::class, 'showResetPassword'])->name('akun-rt.reset-password');
    Route::post('/akun-rt/{user}/reset-password', [AkunRtController::class, 'resetPassword'])->name('akun-rt.reset-password.update');

});


/*
|--------------------------------------------------------------------------
| RT (Admin RT)
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'role:rt'])->prefix('rt')->name('rt.')->group(function () {

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'rt'])->name('dashboard');

    // Pengaduan (hanya index, show, update status)
    Route::get('pengaduan', [RtPengaduanController::class, 'index'])->name('pengaduan.index');
    Route::get('pengaduan/{pengaduan}', [RtPengaduanController::class, 'show'])->name('pengaduan.show');
    Route::put('pengaduan/{pengaduan}/status', [RtPengaduanController::class, 'updateStatus'])->name('pengaduan.updateStatus');

    // UMKM (hanya index & verifikasi)
    Route::get('umkm', [RtUmkmController::class, 'index'])->name('umkm.index');
    Route::put('umkm/{umkm}/status', [RtUmkmController::class, 'updateStatus'])->name('umkm.updateStatus');

    // Informasi & Kegiatan (CRUD penuh)
    Route::resource('informasi', RtInformasiController::class);
    Route::resource('kegiatan', RtKegiatanController::class);

    // ==================== KAS RT (RT lihat kas RT sendiri) ====================
    Route::get('/kas', [RtKasController::class, 'index'])->name('kas.index');

    Route::get('/warga', [RtWargaController::class, 'index'])->name('warga.index');
});


/*
|--------------------------------------------------------------------------
| BENDAHARA (warga yang ditunjuk bendahara)
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'bendahara'])->prefix('bendahara')->name('bendahara.')->group(function () {
    // Dashboard = list kas
    Route::get('/dashboard', [BendaharaKasController::class, 'index'])->name('dashboard');

    // CRUD Kas
    Route::get('/kas', [BendaharaKasController::class, 'index'])->name('kas.index');
    Route::get('/kas/create', [BendaharaKasController::class, 'create'])->name('kas.create');
    Route::post('/kas', [BendaharaKasController::class, 'store'])->name('kas.store');
    Route::get('/kas/{kas}', [BendaharaKasController::class, 'show'])->name('kas.show');
    Route::get('/kas/{kas}/edit', [BendaharaKasController::class, 'edit'])->name('kas.edit');
    Route::put('/kas/{kas}', [BendaharaKasController::class, 'update'])->name('kas.update');
    Route::delete('/kas/{kas}', [BendaharaKasController::class, 'destroy'])->name('kas.destroy');
});


/*
|--------------------------------------------------------------------------
| WARGA
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'role:warga'])->prefix('warga')->name('warga.')->group(function () {

    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'warga'])->name('dashboard');

    // Profil
    Route::get('/profile', [WargaProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/profile', [WargaProfileController::class, 'update'])->name('profile.update');

    // Pengaduan & UMKM
    Route::resource('pengaduan', WargaPengaduanController::class);
    Route::resource('umkm', WargaUmkmController::class);

    // ==================== KAS RT (warga lihat kas RT sendiri, read-only) ====================
    Route::get('/kas', [WargaKasController::class, 'index'])->name('kas.index');
});