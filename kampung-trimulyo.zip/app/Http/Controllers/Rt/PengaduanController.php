<?php

namespace App\Http\Controllers\Rt;

use App\Http\Controllers\Controller;
use App\Models\Pengaduan;
use App\Models\RiwayatPengaduan;
use App\Models\Rt;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PengaduanController extends Controller
{
    private function getRt()
    {
        $rt = Auth::user()->rt;

        if (!$rt) {
            abort(404, "Data RT tidak ditemukan untuk akun ini.");
        }

        return $rt;
    }

    public function index(Request $request)
    {
        $rt = $this->getRt();
        $query = Pengaduan::with(['kategori', 'warga'])
            ->where('rt_id', $rt->id);

        if ($request->filled('search')) {
            $query->where('judul', 'like', '%' . $request->search . '%');
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $pengaduan = $query->latest()->paginate(20)->withQueryString();

        return view('rt.pengaduan.index', compact('pengaduan'));
    }

    public function show(Pengaduan $pengaduan)
    {
        $rt = $this->getRt();
        if ($pengaduan->rt_id !== $rt->id) abort(403);

        $pengaduan->load('kategori', 'warga', 'riwayat.user');
        return view('rt.pengaduan.show', compact('pengaduan'));
    }

    public function updateStatus(Request $request, Pengaduan $pengaduan)
    {
        $rt = $this->getRt();
        if ($pengaduan->rt_id !== $rt->id) abort(403);

        $validated = $request->validate([
            'status'  => ['required', 'in:diterima,diproses,selesai,ditolak'],
            'catatan' => ['nullable', 'string'],
        ]);

        DB::transaction(function () use ($validated, $pengaduan) {
            $pengaduan->update([
                'status'  => $validated['status'],
                'catatan' => $validated['catatan'] ?? $pengaduan->catatan,
            ]);

            RiwayatPengaduan::create([
                'pengaduan_id' => $pengaduan->id,
                'user_id'      => Auth::id(),
                'status'       => $validated['status'],
                'catatan'      => $validated['catatan'] ?? null,
            ]);
        });

        return redirect()->route('rt.pengaduan.show', $pengaduan->id)->with('success', 'Status berhasil diubah.');
    }
}